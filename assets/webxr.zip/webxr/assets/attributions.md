# Attributions

## ArcticFox_Posed

By [Naomi Chen](https://poly.google.com/user/f8cGQY15_-g) / [CC-BY] ([source](https://poly.google.com/view/dK08uQ8-Zm9))

[CC-BY]: https://creativecommons.org/licenses/by/2.0/
